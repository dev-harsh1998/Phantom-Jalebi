An script That Flashes Kernel for devices in recoveries like Cm etc its simple to use just place Zimage & dtb , Zimage-dtb and edit Flash Kernel.sh Accordingly have fun installing your Custom Kernel

Credits
Osmosis : For Unpack & repack tools
and i could take rest for this script etc :p

Warning -> ITS CURRENTLY FOR YU YUNIQUE ONLY BE SURE TO MODIFY FIRST
